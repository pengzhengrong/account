create table "products" ("id" int not null, "name" varchar(32), "amount" integer, "price" decimal(22,4), "created_at" timestamp, "updated_at" timestamp, "deleted_at" timestamp, primary key ("id"))
