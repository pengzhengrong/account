drop table employees
drop table departments
drop table customers
drop table products
drop table orders
drop table logs
