drop table "products"
