create table products (id int not null, name varchar(32), amount integer, price decimal(22,4), created_at datetime, updated_at datetime, deleted_at datetime, primary key (id))
