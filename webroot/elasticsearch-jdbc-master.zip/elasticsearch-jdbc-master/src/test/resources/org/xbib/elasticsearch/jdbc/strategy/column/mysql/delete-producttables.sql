drop table products
