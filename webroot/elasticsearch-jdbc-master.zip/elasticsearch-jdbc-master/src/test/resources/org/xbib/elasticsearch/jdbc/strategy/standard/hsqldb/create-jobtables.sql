create table products ("_job" integer, "name" varchar(32), "amount" integer, "price" decimal(22,4))
