drop table COFFEES
drop table SUPPLIERS
drop procedure SHOW_SUPPLIERS
drop procedure GET_SUPPLIER_OF_COFFEE