/**
 * Pipeline service for multi-threaded importing
 */
package org.xbib.pipeline;
